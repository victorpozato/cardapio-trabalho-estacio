const novo_prato = async function(){
    console.log('Iniciando novo_prato');
    const nome = document.getElementById("nome-prato").value;
    const preco = document.getElementById("preco-prato").value;
    const ingredientes = document.getElementById("ingredientes-prato").value;
    console.log(nome, preco, ingredientes);
    // juntar essas info em um corpo de HTTP
    const dados = {
        nome: nome,
        preco: preco,
        ingredientes: ingredientes,
    };
    console.log(dados);
     console.log(JSON.stringify(dados));
    // fazer um await fetch para enviar esse HTTP com POST
    let resposta;
    try {
         resposta = await fetch('adiciona_prato', {
            method: 'POST',
            body: JSON.stringify(dados),
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            }
        });
    } catch (erro) {
        if (erro instanceof TypeError) {
            alert('Erro ao se conectar com o servidor');
        }

        alert(`Erro grave: ${erro.message}; Contate o suporte suporte@alunos.estacio.br - ${erro.stack}`)

        
    }
    
    if (resposta.ok) { // atualizar a lista no div
        novo_prato_na_lista(nome, preco, );
        fecharModal();
        mostrarToast();
    } else if (resposta.status == 420) {
        // informar o usuário
        alert('Prato já existe!!')
    } else {
        alert('Algum erro ocorreu!')
    }
    
}

window.addEventListener(
    "load",
    () => {document.getElementById("botao_sub_prato").addEventListener(
        "click", novo_prato
    )}
); 

function mostrarToast() {
    const toast = document.getElementById("toast");
    toast.classList.add("mostrar");
    setTimeout(() => {
        toast.classList.remove("mostrar");
    }, 3000); 
}


function abrirModal() {
    // Close edit modal if open
    const modalEditar = document.getElementById("modal-editar-prato");
    if (modalEditar && modalEditar.classList.contains("aberto")) {
        modalEditar.classList.remove("aberto");
    }
    document.getElementById("modal-prato").classList.add("aberto");
  }
  

  function fecharModal() {
    document.getElementById("modal-prato").classList.remove("aberto");
  }

  const novoPrato = async function () {
    const id = document.getElementById("botao_sub_prato").getAttribute("data-id");
    const nome = document.getElementById("nome-prato").value;
    const preco = document.getElementById("preco-prato").value;
    const ingredientes = document.getElementById("ingredientes-prato").value;

    const dados = { nome, preco, ingredientes };

    let url = id ? `/editar_prato/${id}` : "/adiciona_prato";  // Se existir ID, edita

    let resposta = await fetch(url, {
        method: 'POST',
        body: JSON.stringify(dados),
        headers: { "Content-Type": "application/json" }
    });

    if (resposta.ok) {
        alert(id ? "Prato editado com sucesso!" : "Prato cadastrado com sucesso!");
        fecharModal();
        limparCampos();
        location.reload();  // Atualiza a lista
    } else {
        alert("Erro ao salvar o prato.");
    }
};

function limparCampos() {
    document.getElementById("nome-prato").value = "";
    document.getElementById("ingredientes-prato").value = "";
    document.getElementById("preco-prato").value = "";
    document.getElementById("botao_sub_prato").removeAttribute("data-id");
}
