document.addEventListener('DOMContentLoaded', function() {
    const excluirBtn = document.getElementById('excluir');
    if (!excluirBtn) {
        console.error('Botão excluir não encontrado no DOM.');
        return;
    }
    excluirBtn.addEventListener('click', async function() {
        const lista = document.getElementById('lista-de-pratos');
        if (!lista) {
            alert('Lista de pratos não carregada.');
            return;
        }
        const selecionado = lista.querySelector('li.selecionado');
        if (!selecionado) {
            alert('Por favor, selecione um prato para excluir.');
            return;
        }
        const id = selecionado.dataset.id;
        if (!id) {
            alert('ID do prato selecionado não encontrado.');
            return;
        }

        if (!confirm('Tem certeza que deseja excluir o prato selecionado?')) {
            return;
        }

        try {
            const response = await fetch('/deleta_prato', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ id: id })
            });
            if (response.ok) {
                alert('Prato excluído com sucesso.');
                if (typeof window.atualiza_cardapio === 'function') {
                    window.atualiza_cardapio();
                } else {
                    window.location.reload();
                }
            } else {
                const errorText = await response.text();
                alert('Erro ao excluir prato: ' + errorText);
            }
        } catch (error) {
            alert('Erro na requisição: ' + error.message);
        }
    });
});
