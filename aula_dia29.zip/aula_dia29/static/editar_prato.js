 document.addEventListener('DOMContentLoaded', function() {
    const editarBtn = document.getElementById('edit');
    if (!editarBtn) {
        console.error('Botão editar não encontrado no DOM.');
        return;
    }

    const abrirModalEditar = function() {
        // Close add modal if open
        const modalAdd = document.getElementById('modal-prato');
        if (modalAdd && modalAdd.classList.contains('aberto')) {
            modalAdd.classList.remove('aberto');
        }
        document.getElementById('modal-editar-prato').classList.add('aberto');
    };

    const fecharModalEditar = function() {
        document.getElementById('modal-editar-prato').classList.remove('aberto');
    };

    const limparCamposEditar = function() {
        document.getElementById('nome-prato-editar').value = '';
        document.getElementById('ingredientes-prato-editar').value = '';
        document.getElementById('preco-prato-editar').value = '';
        document.getElementById('botao_sub_prato_editar').removeAttribute('data-id');
    };

    editarBtn.addEventListener('click', async function() {
        const lista = document.getElementById('lista-de-pratos');
        if (!lista) {
            alert('Lista de pratos não carregada.');
            return;
        }
        const selecionado = lista.querySelector('li.selecionado');
        if (!selecionado) {
            alert('Por favor, selecione um prato para editar.');
            return;
        }
        const id = selecionado.dataset.id;
        if (!id) {
            alert('ID do prato selecionado não encontrado.');
            return;
        }

        // Fetch dish data from backend to pre-fill modal inputs
        try {
            const response = await fetch(`/prato/${id}`);
            if (!response.ok) {
                alert('Erro ao obter dados do prato.');
                return;
            }
            const dados = await response.json();

            // Open edit modal
            abrirModalEditar();

            // Pre-fill inputs with fetched data
            document.getElementById('nome-prato-editar').value = dados.nome || '';
            document.getElementById('ingredientes-prato-editar').value = dados.ingredientes || '';
            document.getElementById('preco-prato-editar').value = dados.preco || '';

            const botaoSubmeter = document.getElementById('botao_sub_prato_editar');

            // Remove previous event listeners to avoid duplicates
            const newBotaoSubmeter = botaoSubmeter.cloneNode(true);
            botaoSubmeter.parentNode.replaceChild(newBotaoSubmeter, botaoSubmeter);

            // Add event listener to submit button to handle edit submit
            newBotaoSubmeter.addEventListener('click', async () => {
                const nome = document.getElementById('nome-prato-editar').value;
                const ingredientes = document.getElementById('ingredientes-prato-editar').value;
                const preco = document.getElementById('preco-prato-editar').value;

                const dadosEnvio = { nome, ingredientes, preco };

                let resposta = await fetch(`/editar_prato/${id}`, {
                    method: 'POST',
                    body: JSON.stringify(dadosEnvio),
                    headers: { 'Content-Type': 'application/json' }
                });

                if (resposta.ok) {
                    alert('Prato editado com sucesso!');
                    fecharModalEditar();
                    limparCamposEditar();
                    if (typeof window.atualiza_cardapio === 'function') {
                        window.atualiza_cardapio();
                    } else {
                        window.location.reload();
                    }
                } else {
                    alert('Erro ao editar prato.');
                }
            });
        } catch (error) {
            alert('Erro ao obter dados do prato: ' + error.message);
        }
    });

    // Attach functions to window for external access if needed
    window.abrirModalEditar = abrirModalEditar;
    window.fecharModalEditar = fecharModalEditar;
    window.limparCamposEditar = limparCamposEditar;

    // Define editarModal function for inline onclick in index.html
    window.editarModal = function() {
        editarBtn.click();
    };
});
