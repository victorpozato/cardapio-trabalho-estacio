const toggleSenha = document.getElementById('toggleSenha');
    const senhaInput = document.getElementById('senha');

    toggleSenha.addEventListener('click', () => {
      const tipo = senhaInput.getAttribute('type') === 'password' ? 'text' : 'password';
      senhaInput.setAttribute('type', tipo);
      // opcional: mudar o ícone para "olho fechado"
      if (tipo === 'text') {
        toggleSenha.innerHTML = `
          <path d="M12 5c-7 0-11 7-11 7s4 7 11 7 11-7 11-7-4-7-11-7zm0 12a5 5 0 0 1-5-5c0-1.1.45-2.1 1.17-2.83l-1.42-1.42A7 7 0 0 0 4 12s4-7 8-7c1.91 0 3.63.84 4.78 2.18l-1.42 1.42A4.99 4.99 0 0 1 12 17zm6.6 2.6L18 18.99l-1.6-1.6c-.88.37-1.83.61-2.8.61-4 0-8-4-8-4s1.1-1.93 3.33-3.18l-1.35-1.36L3.39 3.39 2 4.78l3.23 3.22A10.5 10.5 0 0 0 12 5c7 0 11 7 11 7s-.88 1.53-2.4 3.2z"/>
        `;
      } else {
        toggleSenha.innerHTML = `
          <path d="M12 5c-7 0-11 7-11 7s4 7 11 7 11-7 11-7-4-7-11-7zm0 12a5 5 0 1 1 0-10 5 5 0 0 1 0 10z"/>
          <circle cx="12" cy="12" r="2.5"/>
        `;
      }
    });