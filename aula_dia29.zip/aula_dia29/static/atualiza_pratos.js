let itemSelecionado = null;

const atualiza_cardapio = async function(){
    console.log('Solicitando pratos')
    let res = await fetch('lista_pratos');
    console.log('Sucesso! solicitação concluida')
    let pratos = await res.json();
    console.log(pratos);
    let lista = cria_lista(pratos);
    coloca_lista_no_div(lista);
    adiciona_eventos_selecao(lista);
}

const cria_lista = function(pratos) {
    const lista = document.createElement('ul');
    lista.id = 'lista-de-pratos';
    for (const p of pratos) {
        novo_item_na_lista(p.nome, p.preco, lista, p.id);
    }
    return lista;
}

const coloca_lista_no_div = function(lista){
    const div = document.getElementById('lista-cardapio');
    div.innerHTML = ''; // Clear previous list if any
    div.appendChild(lista);
}

const adiciona_eventos_selecao = function(lista) {
    const botoesEditar = document.getElementById('edit');
    const botoesExcluir = document.getElementById('excluir');
    botoesEditar.disabled = true;
    botoesExcluir.disabled = true;

    for (const li of lista.children) {
        li.style.cursor = 'pointer';
        li.addEventListener('click', function() {
            if (itemSelecionado) {
                itemSelecionado.classList.remove('selecionado');
            }
            if (itemSelecionado === li) {
                // Deselect if clicking the same item
                itemSelecionado = null;
                botoesEditar.disabled = true;
                botoesExcluir.disabled = true;
            } else {
                itemSelecionado = li;
                li.classList.add('selecionado');
                botoesEditar.disabled = false;
                botoesExcluir.disabled = false;
            }
        });
    }
}

const novo_prato_na_lista = function(nome, preco) {
    novo_item_na_lista(nome, preco, document.getElementById('lista-de-pratos'));
}

const novo_item_na_lista = function(nome, preco, lista, id){
    const item_1 = document.createElement('li');
    const prc = new Intl.NumberFormat("pt-BR",
        { style: "currency", currency: "BRL" }).format(preco);
    item_1.textContent = `${nome}, ${prc}`;
    item_1.dataset.id = id;
    lista.appendChild(item_1);
}

window.addEventListener("load", atualiza_cardapio);












const demorada = function (){
    console.log("Começando função demorada");
    let n = 100000;
    let r = 1;
    for (i=0; i< n; i++){
        for (k=0; k< n; k++){
            r *= -1;
        }
    }
    console.log("Terminando função demorada");
}