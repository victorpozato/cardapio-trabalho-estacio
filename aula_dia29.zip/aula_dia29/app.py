from flask import Flask, render_template, request, redirect, url_for, jsonify
from pratos import obtem_todos_pratos, novo_prato, PratoJaExiste, deleta_prato

import sqlite3
import time

app = Flask(__name__)

#app.url_for('static', filename='estilos.css')

@app.route("/", methods=["GET"])
def login():
    return render_template("TELA_LOGIN.html")

@app.route("/login", methods=["POST"])
def autenticar():
    email = request.form.get("email")
    senha = request.form.get("senha")

    #credenciais 
    if email == "admin@email.com" and senha == "12345":
        return redirect(url_for("menu"))  # Redireciona ao menu se estiver correto
    else:
        return "Login inválido! Tente novamente."


@app.route('/menu')
def menu():
    pratos = obtem_todos_pratos()
    return render_template('index.html', pratos=pratos)
    
@app.route('/lista_pratos')
def lista_pratos():
    pratos = obtem_todos_pratos()
    #time.sleep(10)
    #print("Pratos:", pratos)
    return jsonify(pratos)

@app.route('/adiciona_prato', methods=['get','POST'])
def adiciona_prato():
    dados = request.json
    try:
        novo_prato(dados['nome'],
                   dados['ingredientes'],
                   float(dados['preco']))
    except PratoJaExiste:
        return 'Prato já existe', 420
    return 'OK'

@app.route('/deleta_prato', methods=['POST'])
def deleta_prato_route():
    dados = request.json
    id_prato = dados['id']
    
    try:
        deleta_prato(id_prato)  # Função existente em pratos.py
        
        return 'OK', 200
    except Exception as e:
        return str(e), 400

@app.route('/editar_prato/<int:id>', methods=['POST'])
def editar_prato_route(id):
    dados = request.json
    nome = dados.get('nome')
    ingredientes = dados.get('ingredientes')
    preco = dados.get('preco')

    try:
        from pratos import atualiza_informacoes, obtem_dados
        # Fetch current dish data by id to get the name
        con = sqlite3.connect('base_dados.db')
        cur = con.cursor()
        cur.execute("SELECT nome FROM pratos WHERE id=?", (id,))
        row = cur.fetchone()
        con.close()
        if row is None:
            return 'Prato não encontrado', 404
        nome_atual = row[0]
        prato = obtem_dados(nome_atual)
        atualiza_informacoes(id, nome, ingredientes, float(preco))
        return 'OK', 200
    except Exception as e:
        return str(e), 400

@app.route('/prato/<int:id>', methods=['GET'])
def get_prato(id):
    try:
        con = sqlite3.connect('base_dados.db')
        cur = con.cursor()
        cur.execute("SELECT nome, ingredientes, preco FROM pratos WHERE id=?", (id,))
        row = cur.fetchone()
        con.close()
        if row is None:
            return 'Prato não encontrado', 404
        prato = {
            'nome': row[0],
            'ingredientes': row[1],
            'preco': row[2]
        }
        return jsonify(prato)
    except Exception as e:
        return str(e), 400
    
if __name__ == '__main__':
    app.run(debug=True)
